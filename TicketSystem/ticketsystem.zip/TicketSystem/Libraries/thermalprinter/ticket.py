#!/usr/bin/python
from Adafruit_Thermal import *
from PIL import Image
from datetime import datetime
import qrcode

def makeTicket(jsonResponse):

    printer = Adafruit_Thermal("/dev/serial0", 9600, timeout=5)

    printer.setSize('L')   # Set type size, accepts 'S', 'M', 'L'
    printer.justify('C')
    printer.println("BDM OFFICE")
    printer.println(jsonResponse['branch'])
    printer.setSize('M') 
    printer.println("WALK-IN")
    printer.setLineHeight(50)
    printer.boldOn()
    printer.doubleHeightOn()
    printer.setSize('L')
    printer.println("\n" + jsonResponse['queue']) # To be replaced w Queue Number from API
    printer.boldOff()
    printer.doubleHeightOff()
    printer.setLineHeight()

    #qr = Image.open('qr.png')
    qr = generateQR(jsonResponse)
    
    img = printer.centerQR(qr)
    printer.printImage(img,True)

    printer.setSize('S')
    printer.justify('C')
    printer.println(datetime.now().strftime('%d-%m-%Y %H:%M:%S'))


    printer.feed(2)
    printer.sleep()      # Tell printer to sleep
    printer.wake()       # Call wake() before printing again, even if reset
    printer.setDefault() # Restore printer to defaults
    

def generateQR(jsonResponse):
    qr_img = qrcode.make(jsonResponse)
    return qr_img
    
    


    
    